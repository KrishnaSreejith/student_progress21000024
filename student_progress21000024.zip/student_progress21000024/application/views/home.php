<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Develop a web based Student Progress Report System</title>
        <link rel="stylesheet" href="<?php echo base_url(); ?>site/styles.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <link rel="stylesheet" href="<?php echo base_url(); ?>site/data.css">
</head>
<body>
<div class="container">
    
    <h1 class="page-header text-center"><u>Add student Details</u><span style=" margin-left: 600px"><a href="<?php echo base_url(); ?>index.php/user/logout" class="btn btn-danger">Logout</a><a href="<?php echo base_url(); ?>index.php/user/viewranks" class="btn btn-success">View Students Ranks</a> </span></h1>			
	<div class="row">
		<div class="col-md-4 col-md-offset-4">
                    
                    <div>
    <b style="color: #5cb85c;"> 
     <?=$this->session->tempdata('success_msg');?></b>
        <b  style="color: #E13300;"> <?=$this->session->tempdata('error_msg');?></b></div>
                    <form method="post" action="<?= base_url() ?>user/savedatas" enctype="multipart/form-data">

			<div style="width:50%; margin-right:200px;">

        <label for="fname">Admission Number</label>
        <input type="text"  name="admnumber" placeholder="Admission Number"  required="">

    <label for="lname" >Student Name</label>
    <input type="text"  name="sname" placeholder="Student Name" required  >
         
 <label for="country" >Date of birth</label>
 <input type="date"  name="dob" placeholder="Date of birth" required>

    <label for="country" >Class/Course</label>
    <input type="text"  name="course" placeholder="Class/Course" required >
   
    <label for="country" >English Score</label>
    <input type="number"  name="english_score" max="100"min="0" placeholder="Score" required >
   <label for="country" >Malayalam Score</label>
   <input type="number"  name="malayalam_score" max="100"min="0" placeholder="Score"required >
    <label for="country" >Hindi Score</label>
    <input type="number" name="hindi_score" max="100"min="0" placeholder="Score" required >
   
    <label for="country" >Maths Score</label>
    <input type="number"  name="maths_score" max="100"min="0" placeholder="Score" required >
   
<label for="country">Upload Photo:</label>
<input name="image" type="file" required><br><br>
<input type="submit" class="btn btn-primary"  name="userSubmit" value="Submit">
     
    
   
   
</div>
                    </form>
		</div>
	</div>

</div>
</body>
 
</html>
