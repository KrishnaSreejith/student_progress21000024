<!DOCTYPE html>
<html>
<head>
    <title>Employee Organization</title>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="<?php echo base_url(); ?>site/styles.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

</head>

<body>
<h11><u>Students Rank List</u><?php if(!empty($studentsinfo)){?>(Total Records :  <?php  echo  $total_count; ?> ) <?php } ?>
 </h11><span style=" margin-left: 600px"><a href="<?php echo base_url(); ?>user/home" class="btn btn-primary">Back</a>
     

  
<table style="width:70%">
  <tr>
    
    <th>Admission Number</th>
    <th>Students Name</th> 
    <th>Date of Birth</th>
    <th>Class or Course</th>
    <th>Marks</th>
    <th>Total Marks</th>
    <th>Rank</th> 
   
  </tr>
  <?php 
  
  if(!empty($studentsinfo)){
$x= 1 + ($this->pagination->cur_page-1)*$this->pagination->per_page;      //print_r($studentsinfo);exit;
   foreach ($studentsinfo as $value) {
    
       $total  = $value['english'] + $value['malayalam'] + $value['hindi'] + $value['maths'];
      
  ?>
  <tr>
     <td><?php echo $value['admissin_no'];?></td>
     <td><?php echo $value['name'];?><img src="<?php echo base_url('site/'. $value['image']);?>"  width="100" height="100" /></td>
     <td><?php echo $value['dob'];?></td>
     <td><?php echo $value['class_course'];?></td>
     <td>English : <?php echo $value['english'];?><br>
         
         Malayalam : <?php echo $value['malayalam'];?><br>
         
         Hindi : <?php echo $value['hindi'];?><br>
         
         Maths : <?php echo $value['maths'];?><br>
     </td>
     
     <td><?php echo $value['total_score'];?></td>
     <td> <?php echo $x++;?> </td>

     
  </tr>
   <?php  } }else { ?>
  
 <tbody>
 <tr><td colspan="7">No Record(s) found.....</td></tr>
 </tbody>
 
 <?php } ?>
 
</table>
    <br><br><br><br>
          <span style="width:40%">
              
            <?php if (isset($studentsinfo) && is_array($studentsinfo)) echo $page_links; ?>
              
          </span>
        
    





</body>
</html>
