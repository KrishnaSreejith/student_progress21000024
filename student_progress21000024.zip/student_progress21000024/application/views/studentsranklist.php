<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <title>Student Profile Page Design Example</title>

    <meta name="author" content="Codeconvey" />
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,900&display=swap" rel="stylesheet">
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css'>
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.1/css/all.min.css'>

    <!--Only for demo purpose - no need to add.-->
    <link rel="stylesheet" href="<?php echo base_url();?>css/demo.css" />
    
	    <link rel="stylesheet" href="<?php echo base_url();?>css/style.css">
</head>
<body>
		
<div class="ScriptTop">
    <div class="rt-container">
        <div class="col-rt-4" id="float-right">
 
            <!-- Ad Here -->
            
        </div>
        <div class="col-rt-2">
            <ul>
                <li><a href="<?php echo base_url();?>user/studentlogout" title="Back to tutorial page">Logout</a></li>
            </ul>
        </div>
    </div>
</div>

<header class="ScriptHeader">
    <div class="rt-container">
    	<div class="col-rt-12">
        	<div class="rt-heading">
            	<h1>Student Profile</h1>
               
            </div>
        </div>
    </div>
</header>

<section>
    <div class="rt-container">
          <div class="col-rt-12">
              <div class="Scriptcontent">
              
<!-- Student Profile -->
<div class="student-profile py-4">
  <div class="container">
    <div class="row">
      <div class="col-lg-4">
        <div class="card shadow-sm">
            <?php
				$user = $this->session->userdata('student');
				extract($user);
                                
			?>
          <div class="card-header bg-transparent text-center">
            <img class="profile_img" src="<?php echo base_url('site/'. $image);?>"" alt="student dp">
            <h3><?php echo $name; ?></h3>
          </div>
          <div class="card-body">
            <p class="mb-0"><strong class="pr-1">Admission Number:</strong><?php echo $admissin_no; ?></p>
            <p class="mb-0"><strong class="pr-1">Class / Course:</strong><?php echo $class_course; ?></p>
            <p class="mb-0"><strong class="pr-1">D.O.B :</strong><?php echo date("d-m-Y", strtotime($dob)); ?></p>
          </div>
        </div>
      </div>
      <div class="col-lg-8">
        <div class="card shadow-sm">
          <div class="card-header bg-transparent border-0">
            <h3 class="mb-0"><i class="far fa-clone pr-1"></i>Students Rank List</h3>
          </div>
          <div class="card-body pt-0">
            <table class="table table-bordered">
                  <tr>
    
    
                      <th style=" color: red">Students Name</th> 
    
    <th></th> 
   <th style=" color: red">Rank</th> 
  </tr>
                <?php if(!empty($studentsinfo)){
$x= 1 + ($this->pagination->cur_page-1)*$this->pagination->per_page;      //print_r($studentsinfo);exit;
   foreach ($studentsinfo as $value) {
     ?>
              <tr>
                <th width="30%"><?php echo $value['name'];?></th>
                <td width="2%">:</td>
                <td><?php echo $x++;?></td>
              </tr>
                <?php } }else {?>
              <tbody>
 <tr><td colspan="7">No Record(s) found.....</td></tr>
                </tbody><?php } ?>
         
            </table>
          </div>
             <?php if (isset($studentsinfo) && is_array($studentsinfo)) echo $page_links; ?>
        </div>
          <div style="height: 26px"></div>
        
      </div>
    </div>
  </div>
</div>
<!-- partial -->
           
    		</div>
		</div>
    </div>
</section>
     


    <!-- Analytics -->

	</body>
</html>