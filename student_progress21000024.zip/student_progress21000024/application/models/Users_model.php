<?php
	class Users_model extends CI_Model {
             private $_limit;
            private $_pageNumber;
            private $_offset;
		function __construct(){
                    
			parent::__construct();
			$this->load->database();
		}

		public function login($username, $password){
			$query = $this->db->get_where('institution_login', array('username'=>$username, 'password'=>$password));
			return $query->row_array();
		}
                
     public function studentlogin($username, $password){
			$query = $this->db->get_where('student_details', array('admissin_no'=>$username, 'dob'=>$password));
			return $query->row_array();
		}
                
    public function insertdata($data) {
      
      $this->db->insert('student_details',$data);
      
  }
       
public function saverecords($data)
	{
	$query = $this->db->insert('student_details',$data);
        
	return $query;
	}

        public function setPageNumber($pageNumber) {
    
        $this->_pageNumber = $pageNumber;
    }
 
public function setOffset($offset) {
    
        $this->_offset = $offset;
    }
    
    
// Count all record of table "employee_info" in database.
public function getAllStudentsCount() {
        $this->db->from('student_details');
        
        return $this->db->count_all_results();
    }
    
  // Fetch data according to per_page limit.
  public function studentList() {       

       
        $this->db->select(array('admissin_no', 'name', 'dob', 'class_course', 'english','malayalam','hindi','maths','total_score','image'));
        $this->db->from('student_details');   
        $this->db->order_by('total_score', 'desc');
        $this->db->limit($this->_pageNumber, $this->_offset);
        $query = $this->db->get();
        return $query->result_array();
    }
    
    
    public function studentrankList() {       

        $this->db->select(array('admissin_no', 'name', 'dob', 'class_course', 'english','malayalam','hindi','maths','total_score','image'));
        $this->db->from('student_details');   
        $this->db->order_by('total_score', 'desc');
        $this->db->limit($this->_pageNumber, $this->_offset);
        $query = $this->db->get();
        return $query->result_array();
    }
    public function getAllrankCount() {
        $this->db->from('student_details');
        
        return $this->db->count_all_results();
    }
    
	}
?>