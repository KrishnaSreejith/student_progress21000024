<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

	function __construct(){
		parent::__construct();
                $this->load->helper('form');
		$this->load->helper('url');
                $this->load->library('form_validation');
                $this->load->library('user_agent');
                $this->load->helper('file');
		$this->load->model('users_model');
                $this->load->database();
                $this->load->library('session');
                $this->load->library("pagination");
                $this->perPage = 5; 
	}

	public function index(){
            
		$this->load->library('session');

		if($this->session->userdata('user')){
			redirect('user/home');
		}
		else{
			$this->load->view('login_page');
		}
	}

        public function login(){
            
		$this->load->library('session');

		$output = array('error' => false);

		$username = $_POST['username'];
		$password = $_POST['password'];

		$data = $this->users_model->login($username, $password);

		if($data){
			$this->session->set_userdata('user', $data);
			$output['message'] = 'Logging in. Please wait...';
		}
		else{
			$output['error'] = true;
			$output['message'] = 'Login Invalid. User not found';
		}

		echo json_encode($output); 
	}

        public function home(){
		//load session library
		$this->load->library('session');

		//restrict users to go to home if not logged in
		if($this->session->userdata('user')){
			$this->load->view('home');
		}
		else{
			redirect('/');
		}
		
	}

        public function logout(){
		//load session library
		$this->load->library('session');
		$this->session->unset_userdata('user');
		redirect('/');
	}
        
        
        public function create_user(){
		
          $this->load->view('signup');
		
		
	}


        public function savedatas(){
    
            if($this->input->post('userSubmit')){
            
            
            if(!empty($_FILES['image']['name'])){
            $config['upload_path'] = './site/';
            $config['allowed_types'] = 'jpg|png|jpeg';
            $config['max_size'] = 100;
            $config['max_width'] = 1024;
            $config['max_height'] = 768;

            $this->load->library('upload',$config);

            if(!$this->upload->do_upload('image')){
               // print_r($this->upload->display_errors());
            }else{

                $announce_image = $this->upload->data('file_name');
            }
            
                        $admnumber=$this->input->post('admnumber');
			$sname=$this->input->post('sname');
			$dob=$this->input->post('dob');
			$course=$this->input->post('course');
                        $english=$this->input->post('english_score');
                        $malayalam=$this->input->post('malayalam_score');
                        $hindi=$this->input->post('hindi_score');
                        $maths=$this->input->post('maths_score');
                        $total = $english+$malayalam+$hindi+$maths;
                       
             $data = array(
			'admissin_no'	=> $admnumber,
			'name' => $sname,
			'dob'	=> $dob,
                        'class_course'	=> $course,
                        'english'	=> $english,
                        'malayalam'	=> $malayalam,
                        'hindi'	=> $hindi,
                        'maths'	=> $maths,
                        'total_score'=>$total,
                        'image' =>$announce_image
                            
		);

            $insertUserData = $this->users_model->insertdata($data);
             $this->session->set_tempdata('success_msg', 'User data have been added successfully.',2);

            }else {
              $this->session->set_tempdata('error_msg', 'Some problems occured, please try again.',2 );

            }
           
            
        }
       
        redirect('user/home','refresh');    


            }




        public function viewranks(){
            $config['total_rows'] = $this->users_model->getAllStudentsCount();
            $data['total_count'] = $config['total_rows'];
            $config['suffix'] = '';
            if ($config['total_rows'] > 0) {
            $page_number = $this->uri->segment(3);
            if ($page_number > 0) {
                $config['base_url'] = base_url() . 'user/viewranks/';
            } else {
                $config['base_url'] = base_url() . 'user/viewranks/';
            }
            if (empty($page_number))
            $page_number = 1;
            $offset = ($page_number - 1) * $this->pagination->per_page;
            $this->users_model->setPageNumber($this->pagination->per_page);
            $this->users_model->setOffset($offset);
            $this->pagination->cur_page = $offset;
            $config['attributes'] = array('class' => 'page-link');
            $this->pagination->initialize($config);
            $data['page_links'] = $this->pagination->create_links();
            $data['studentsinfo'] = $this->users_model->studentList();
        }
        $this->load->view('viewranks', $data);
    }
    

        public function studentlogin(){
		
	    $this->load->library('session');

	    if($this->session->userdata('student')){
	     redirect('user/studenthome');
		}
		else{
			$this->load->view('studentlogin');
		}
		
	}
    
        public function studentprofile(){
     
		$this->load->library('session');

		$output = array('error' => false);

		$username = $_POST['username'];
		$password = $_POST['password'];

		$data = $this->users_model->studentlogin($username, $password);

		if($data){
			$this->session->set_userdata('student', $data);
			$output['message'] = 'Logging in. Please wait...';
		}
		else{
			$output['error'] = true;
			$output['message'] = 'Login Invalid. User not found';
		}

		echo json_encode($output);          
        
	        }
        
        
        
        public function studenthome(){
		$this->load->library('session');

		if($this->session->userdata('student')){
		$this->load->view('studentprofile');
		}
		else{
			redirect('/');
		}
                
                }
    
    
        public function studentlogout(){
		$this->load->library('session');
		$this->session->unset_userdata('student');
		redirect('user/studentlogin');
	}  
        
        public function studentsranklist(){
		
            $config['total_rows'] = $this->users_model->getAllrankCount();
            $data['total_count'] = $config['total_rows'];
            $config['suffix'] = '';
            if ($config['total_rows'] > 0) {
            $page_number = $this->uri->segment(3);
            if ($page_number > 0) {
                $config['base_url'] = base_url() . 'user/studentsranklist/';
            } else {
                $config['base_url'] = base_url() . 'user/studentsranklist/';
            }
            if (empty($page_number))
            $page_number = 1;
            $offset = ($page_number - 1) * $this->pagination->per_page;
            $this->users_model->setPageNumber($this->pagination->per_page);
            $this->users_model->setOffset($offset);
            $this->pagination->cur_page = $offset;
            $config['attributes'] = array('class' => 'page-link');
            $this->pagination->initialize($config);
            $data['page_links'] = $this->pagination->create_links();
            $data['studentsinfo'] = $this->users_model->studentrankList();
        }
        $this->load->view('studentsranklist', $data);		
	}
    
        
}
